#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

class cond
{
public:
	vector<int> clause;
	cond* next;
};

int main(int argc, char const *argv[])
{
	ifstream file;
	bool *vars;
	vector<int> imps;
	cond* neg,*head = NULL, *prev = NULL;
	char buff[256];
	string temp;
	int size;
	cout << "Enter file name: ";
	cin >> buff;
	file.open(buff);

	file >> temp >> size;
	vars = new bool[size];
	for(int i = 0; i < size; i++){
		vars[i] = false;
	}
	getline(file, temp);
	while(getline(file, temp)){
		
		int pos = temp.find("=");
		int pos2 = temp.find("x");
		if(pos == -1){
			neg = new cond;
			if(prev)
				prev -> next = neg;
			else
				head = neg;
			neg -> next = NULL;
			prev = neg;
			while(pos2 != -1){
				neg -> clause.push_back(stoi(temp.substr(pos2+1, 1)));
				temp = temp.substr(pos2+1);
				pos2 = temp.find("x");
			}
		} else {
			temp = temp.substr(pos+4);
			imps.push_back(stoi(temp));			//you could set vars[stoi(temp) -1] to true here but i wasnt sure if i was allowed to do that
		}										//that would eliminate the time complexity of a push_back.
	}
	for(int i = 0; i < imps.size(); i++){		//total complexity O(n)
		vars[imps[i] -1] = true;				//setting literals to true in O(1)
	}
	bool check;
	while(head){								//runs for the number clauses, has time complexity of total length of clauses
		check = true;
		for(int i = 0; i < head -> clause.size(); i++){	//length of clause (m) in O(m)
			if(!vars[head -> clause[i] - 1]){			//check literal in O(1)
				check = false;
			}
		}
		if(check)
			break;
		else
			head = head -> next;
	}
	if(check)
		cout << "Not Satisfiable.";
	else{
		cout << "Satisfiable. ";
		for(int i = 0; i < size; i++){
			cout <<"x"<<i+1<<": "<< vars[i]<< " ";
		}
	}
	return 0;
}