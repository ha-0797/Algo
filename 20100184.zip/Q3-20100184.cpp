#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;

class heap_item{
	
public:
	int index;
	int val;
	
};
struct Comp{
    bool operator()(const heap_item& a, const heap_item& b){
        return a.val<b.val;
    }
};

int main(int argc, char const *argv[])
{
	string temp;
    heap_item* t;
	int size, val, *row;
	priority_queue <heap_item, vector<heap_item>, Comp>col;
	ifstream file;
	char buff[256];
	cout << "Enter file name: ";
	cin >> buff;
	file.open(buff);

	file >> temp >> size;
	file >> temp;
	row = new int[size];

	for(int i = 0; i < size; i++){
		file >> val;
		row[i] = val;
	}
	file >> temp;
	for(int i = 0; i < size; i++){
		t = new heap_item;
		t -> index = i +1;
		file >> t -> val;
		col.push(*t);
	}

	for(int i = 0; i < size;i++){				//O(nlog(n))
		t = new heap_item[row[i]];
		for(int j = 0; j < row[i]; j++){			
			t[j] = col.top();
			cout << "(" << i+1 << "," << t[j].index<<") ";
			col.pop();
		}
		for(int j = 0; j < row[i]; j++){		//O(log(n))
			t[j].val--;
			col.push(t[j]);
		}
		cout << endl;
	}
	return 0;
}