#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class node;

class edge{
public:
	node* Origin;
	node* Dest;
	int weight;
	friend bool operator <(edge a, edge b){
		return a.weight < b.weight;
	}
};

class node{
public:
	string name;
	vector<node*> tracks;
};

class graph{
public:
	vector<node*> cities;
	vector<edge> roads;
	vector<edge> mst;
	

	graph(char* file){
		string buff, s_temp;
		ifstream f;
		node* n_temp;
		edge* e_temp;
		int size,w;
		f.open(file);
		f >> buff >> size;
		getline(f, buff);

		//make all nodes
		for(int i = 0; i < size; i++){
			f >> buff;
			buff = buff.substr(0,buff.length()-1);
			n_temp = new node;
			n_temp -> name = buff;
			cities.push_back(n_temp);
			getline(f, buff);
		}


		f.close();
		f.open(file);
		getline(f, buff);

		//make all edges
		for(int i = 0; i < size; i++){
			getline(f, buff);
			int pos = buff.find(":");
			int pos2;
			buff = buff.substr(pos+2);
			while(pos != -1){
				pos = buff.find(";");
				if(pos == -1){
					break;
				} else{
					s_temp = buff.substr(0,pos);
				}
				for(int j = 0; j < size; j++){
					if(cities[j] -> name == s_temp){
						e_temp = new edge;
						e_temp -> Origin = cities[i];
						e_temp -> Dest = cities[j];
						pos2 = buff.find(",");
						if(pos == -1)
							e_temp -> weight = stoi(buff.substr(pos+1));
						else
							e_temp -> weight = stoi(buff.substr(pos+1, pos2-3));
						cities[i] -> tracks.push_back(cities[j]);
						roads.push_back(*e_temp);
						break;
					}
				}
				if(pos2 == -1)
					pos = -1;
				else
					buff = buff.substr(pos + 4);
			}
		}

	}
	void MST(){
		sort(roads.begin(),roads.end());
		for(int i = 0; i < roads.size();i++){
			bool o = false, d= false;
			for(int j = 0; j < mst.size(); j++){
				if(roads[i].Origin == mst[j].Origin ||roads[i].Origin == mst[j].Dest)
					o = true;
				if(roads[i].Dest == mst[j].Origin ||roads[i].Dest == mst[j].Dest)
					d = true;
			}
			if(!(o&&d)){
				cout << roads[i].Origin -> name << " " << roads[i].Dest -> name << " " << roads[i].weight<<endl;
				mst.push_back(roads[i]);
			}
		}
	}
};

int main(int argc, char const *argv[])
{
	node* n_temp;
	edge* e_temp;
	string temp;
	int size;
	ifstream file;
	char buff[256];
	graph* g;
	cout << "Enter file name: ";
	cin >> buff;

	g = new graph(buff);
	g->MST();
	return 0;
}