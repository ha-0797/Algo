#include <iostream>
#include <fstream>

using namespace std;

class MV{
public:
	double T;
	double R;
	double F;
	double fuel;
};

int main(int argc, char const *argv[])
{
	double time = 0;
	ifstream file;
	char buff[256];
	string temp;
	double dist, t_dist = 0;
	cout << "Enter file name: ";
	cin >> buff;
	file.open(buff);
	MV car;
	
	file >> temp >> car.T;
	car.fuel = car.T;
	file >> temp >> car.R;
	file >> temp >> car.F;
	file >> temp >> temp;
	while(!file.eof()){
		file >> temp >> dist;
		if((dist-t_dist)/car.R > car.fuel){
			double t2 = ((dist-t_dist)/car.R -car.fuel)/car.F;
			cout << temp << " " << t2 << ", ";
			time += t2;
			car.fuel = (dist-t_dist)/car.R;
		}
		car.fuel -= ((dist-t_dist) / car.R);
		t_dist = dist;
	}
	cout << endl << "total time: " << time;
	return 0;
}