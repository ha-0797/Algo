#include <iostream>
#include <fstream>

using namespace std;

class merge_item{
public:
	double p;
	double L;
	int index;
	bool operator <(const merge_item &a){
		return p < a.p;
	}
	bool operator >(const merge_item &a){
		return p > a.p;
	}
	bool operator ==(const merge_item &a){
		return p == a.p;
	}
	bool operator <=(const merge_item &a){
		return p <= a.p;
	}
	bool operator >=(const merge_item &a){
		return p >= a.p;
	}

};

void merge(merge_item arr[], int l, int m, int r) 
{ 
    int i, j, k; 
    int n1 = m - l + 1; 
    int n2 =  r - m; 
  
    merge_item L[n1], R[n2]; 
  
    for (i = 0; i < n1; i++) 
        L[i] = arr[l + i]; 
    for (j = 0; j < n2; j++) 
        R[j] = arr[m + 1+ j]; 

    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2) 
    { 
        if (L[i] <= R[j]) 
        { 
            arr[k] = L[i]; 
            i++; 
        } 
        else
        { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
  
    while (i < n1) 
    { 
        arr[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    while (j < n2) 
    { 
        arr[k] = R[j]; 
        j++; 
        k++; 
    } 
} 
  
void mergeSort(merge_item arr[], int l, int r) 
{ 
    if (l < r) 
    { 
        int m = l+(r-l)/2; 
  
        mergeSort(arr, l, m); 
        mergeSort(arr, m+1, r); 
  
        merge(arr, l, m, r); 
    } 
}

int main(int argc, char const *argv[])
{
	string temp;
	int size;
	double *p, *L, val;
	merge_item* m, *t;
	ifstream file;
	char buff[256];
	cout << "Enter file name: ";
	cin >> buff;
	file.open(buff);

	file >> temp >> size;
	p = new double[size];
	L = new double[size];
	m = new merge_item[size];

	file >> temp;
	for(int i = 0; i < size; i++){
		file >> val;
		file >> temp;
		L[i] = val;
	}

	file >> temp;
	for(int i = 0; i < size; i++){
		file >> val;
		file >> temp;
		p[i] = val;
	}

	for(int i = 0; i < size; i++){
		t = new merge_item;
		t -> p = p[i];
		t -> L = L[i];
		t -> index = i + 1;
		m[i] = *t;
	}

	mergeSort(m,0, size-1);
	for(int i = 0; i < size; i++){
		if(i != size-1)
			cout << "rack " << m[i].index << ", ";
		else
			cout << "rack " << m[i].index << endl;
	}
	double exp = 0;
	double total = 0;
	for(int i = size -1; i >=0; i--){
		total+=m[i].L;
		exp+= m[i].p*total;
	}
	cout << exp;
	return 0;
}